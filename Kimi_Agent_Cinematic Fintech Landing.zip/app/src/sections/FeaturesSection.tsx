import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'
import {
  Zap,
  Shield,
  Globe,
  BarChart3,
  Wallet,
  Lock,
  ArrowUpRight,
  RefreshCw,
  CreditCard,
  Bell,
  PieChart,
  Users,
} from 'lucide-react'

const features = [
  {
    icon: Zap,
    title: 'Instant Transfers',
    description: 'Send and receive funds in milliseconds with zero delay processing.',
    colSpan: 'col-span-1',
  },
  {
    icon: Shield,
    title: 'Bank-Grade Security',
    description: '256-bit encryption with multi-factor authentication and biometric verification.',
    colSpan: 'col-span-1',
  },
  {
    icon: Globe,
    title: 'Global Reach',
    description: 'Seamless cross-border transactions in 150+ currencies worldwide.',
    colSpan: 'col-span-1',
  },
  {
    icon: BarChart3,
    title: 'Smart Analytics',
    description: 'AI-powered insights into your spending patterns and financial health.',
    colSpan: 'col-span-1',
  },
  {
    icon: Wallet,
    title: 'Multi-Wallet',
    description: 'Manage multiple wallets and asset types from a single dashboard.',
    colSpan: 'col-span-1',
  },
  {
    icon: Lock,
    title: 'Private Keys',
    description: 'You own your keys. Full custody of your digital assets at all times.',
    colSpan: 'col-span-1',
  },
]

const stats = [
  { icon: RefreshCw, label: 'Real-time Sync', value: '<100ms' },
  { icon: CreditCard, label: 'Card Support', value: 'Visa/MC' },
  { icon: Bell, label: 'Smart Alerts', value: '24/7' },
  { icon: PieChart, label: 'Portfolio View', value: 'Unified' },
  { icon: Users, label: 'Active Users', value: '15K+' },
  { icon: ArrowUpRight, label: 'Uptime', value: '99.99%' },
]

export default function FeaturesSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const isInView = useInView(sectionRef, { once: true, margin: '-100px' })

  return (
    <section
      id="features"
      ref={sectionRef}
      className="relative w-full py-20 lg:py-32 overflow-hidden"
    >
      {/* Gradient background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#050505] via-[#060d1a] to-[#050505]" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-blue-600/5 rounded-full blur-[150px]" />

      <div className="relative z-10 max-w-7xl mx-auto section-padding">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-blue-400 text-xs font-medium tracking-[0.2em] uppercase mb-4 block">
            Core Capabilities
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-light text-white tracking-[-0.02em]">
            Everything you need<br />
            <span className="text-gradient-blue">in one platform</span>
          </h2>
        </motion.div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-12">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.2 + i * 0.1, duration: 0.5 }}
              className={`${feature.colSpan} glass-card glass-card-hover rounded-2xl p-6 group cursor-pointer transition-all duration-300`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center group-hover:bg-blue-500/20 transition-colors">
                  <feature.icon className="w-5 h-5 text-blue-400" />
                </div>
                <ArrowUpRight className="w-4 h-4 text-zinc-600 group-hover:text-blue-400 transition-colors" />
              </div>
              <h3 className="text-white font-medium text-lg mb-2">{feature.title}</h3>
              <p className="text-zinc-500 text-sm leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>

        {/* Stats Row */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4"
        >
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 15 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 1.0 + i * 0.1, duration: 0.4 }}
              className="text-center p-4 rounded-xl bg-white/[0.02] border border-white/5"
            >
              <stat.icon className="w-5 h-5 text-blue-400/60 mx-auto mb-2" />
              <div className="text-white font-medium text-sm">{stat.value}</div>
              <div className="text-zinc-600 text-xs mt-1">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
