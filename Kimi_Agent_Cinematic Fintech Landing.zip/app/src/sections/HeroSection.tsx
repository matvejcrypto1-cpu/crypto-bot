import { useRef, useMemo, Suspense } from 'react'
import { Canvas, useFrame, useLoader } from '@react-three/fiber'
import { Html, Environment, Float } from '@react-three/drei'
import { motion } from 'framer-motion'
import * as THREE from 'three'
import { useMousePosition } from '@/hooks/useMousePosition'
import { ArrowRight } from 'lucide-react'

/* ─── Holographic Ring System (InstancedMesh) ─── */
function HolographicRings() {
  const groupRef = useRef<THREE.Group>(null)
  const ringConfigs = useMemo(
    () => [
      { radius: 3.2, speed: 0.4, points: 80, yOffset: 0 },
      { radius: 4.0, speed: 0.25, points: 120, yOffset: 0.3 },
      { radius: 4.8, speed: 0.15, points: 160, yOffset: -0.2 },
    ],
    []
  )

  const rings = useMemo(() => {
    return ringConfigs.map((config) => {
      const dummy = new THREE.Object3D()
      const positions: THREE.Matrix4[] = []
      for (let i = 0; i < config.points; i++) {
        const angle = (i / config.points) * Math.PI * 2
        dummy.position.set(
          Math.cos(angle) * config.radius,
          config.yOffset + Math.sin(angle * 3) * 0.15,
          Math.sin(angle) * config.radius
        )
        dummy.rotation.set(0, -angle, 0)
        dummy.scale.setScalar(0.02 + Math.random() * 0.01)
        dummy.updateMatrix()
        positions.push(dummy.matrix.clone())
      }
      return { ...config, positions, dummy }
    })
  }, [ringConfigs])

  useFrame(({ clock }) => {
    if (!groupRef.current) return
    const t = clock.getElapsedTime()
    groupRef.current.rotation.y = t * 0.05
    rings.forEach((ring, ringIdx) => {
      const mesh = groupRef.current?.children[ringIdx] as THREE.InstancedMesh
      if (!mesh) return
      for (let i = 0; i < ring.points; i++) {
        const angle = (i / ring.points) * Math.PI * 2 + t * ring.speed
        const waveZ = Math.sin(t * 2 + i * 0.2) * 0.3
        ring.dummy.position.set(
          Math.cos(angle) * ring.radius,
          ring.yOffset + Math.sin(angle * 3) * 0.15 + Math.sin(t + i * 0.1) * 0.1,
          Math.sin(angle) * ring.radius + waveZ
        )
        ring.dummy.rotation.set(t * 0.1, -angle, 0)
        ring.dummy.updateMatrix()
        mesh.setMatrixAt(i, ring.dummy.matrix)
      }
      mesh.instanceMatrix.needsUpdate = true
    })
  })

  return (
    <group ref={groupRef}>
      {rings.map((ring, i) => (
        <instancedMesh key={i} args={[undefined, undefined, ring.points]}>
          <octahedronGeometry args={[1, 0]} />
          <meshStandardMaterial
            color="#3B82F6"
            emissive="#1d4ed8"
            emissiveIntensity={2}
            metalness={0.8}
            roughness={0.2}
            transparent
            opacity={0.6}
          />
        </instancedMesh>
      ))}
    </group>
  )
}

/* ─── Floating 3D Card ─── */
function FloatingCard() {
  const meshRef = useRef<THREE.Mesh>(null)
  const tex = useLoader(THREE.TextureLoader, '/hero-card.png')
  const mouse = useMousePosition()

  useFrame(({ clock }) => {
    if (!meshRef.current) return
    const t = clock.getElapsedTime()
    meshRef.current.rotation.y = THREE.MathUtils.lerp(
      meshRef.current.rotation.y,
      mouse.normalizedX * 0.3,
      0.05
    )
    meshRef.current.rotation.x = THREE.MathUtils.lerp(
      meshRef.current.rotation.x,
      mouse.normalizedY * 0.2,
      0.05
    )
    meshRef.current.position.y = Math.sin(t * 0.8) * 0.15
  })

  return (
    <Float speed={1.5} rotationIntensity={0.3} floatIntensity={0.5}>
      <mesh ref={meshRef} scale={[2.8, 1.8, 0.06]}>
        <boxGeometry />
        <meshPhysicalMaterial
          map={tex}
          metalness={0.9}
          roughness={0.1}
          clearcoat={1}
          clearcoatRoughness={0.1}
          envMapIntensity={1.5}
        />
      </mesh>
    </Float>
  )
}

/* ─── Floating Stat Badges (HTML overlay in 3D) ─── */
function FloatingBadges() {
  return (
    <>
      <Html position={[2.8, 0.8, 0]} center>
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="flex items-center gap-2 px-4 py-2 rounded-full liquid-glass whitespace-nowrap"
        >
          <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
          <span className="text-white text-sm font-medium">+15K Users</span>
        </motion.div>
      </Html>
      <Html position={[2.8, -0.3, 0]} center>
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 1.0, duration: 0.6 }}
          className="flex items-center gap-2 px-4 py-2 rounded-full liquid-glass whitespace-nowrap"
        >
          <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span className="text-white text-sm font-medium">Secure system</span>
        </motion.div>
      </Html>
    </>
  )
}

/* ─── 3D Scene ─── */
function HeroScene() {
  return (
    <>
      <ambientLight intensity={0.3} />
      <spotLight position={[0, 10, 0]} angle={0.3} penumbra={1} intensity={1} color="#ffffff" />
      <pointLight position={[-10, -10, -10]} intensity={2} color="#3B82F6" />
      <pointLight position={[10, 5, 5]} intensity={1} color="#06B6D4" />
      <Environment preset="city" />
      <HolographicRings />
      <FloatingCard />
      <FloatingBadges />
      {/* Radial glow below */}
      <mesh position={[0, -3, -2]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[20, 20]} />
        <meshBasicMaterial
          color="#1d4ed8"
          transparent
          opacity={0.08}
        />
      </mesh>
    </>
  )
}

/* ─── Main Hero Section ─── */
export default function HeroSection() {
  return (
    <section id="hero" className="relative w-full h-screen overflow-hidden bg-[#050505]">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center_bottom,_rgba(29,78,216,0.15)_0%,_transparent_60%)]" />

      {/* Three.js Canvas - Behind the text */}
      <div className="absolute inset-0 z-10">
        <Suspense fallback={null}>
          <Canvas
            camera={{ position: [0, 0, 8], fov: 45 }}
            dpr={[1, 2]}
            gl={{ antialias: true, alpha: true }}
          >
            <HeroScene />
          </Canvas>
        </Suspense>
      </div>

      {/* Navigation */}
      <nav className="absolute top-0 left-0 right-0 z-40 flex items-center justify-between section-padding py-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex items-center gap-2"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
            <span className="text-white font-bold text-sm">L</span>
          </div>
          <span className="text-white font-medium text-lg tracking-tight">Lunétra</span>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="hidden md:flex items-center gap-8"
        >
          <a href="#wallet" className="text-sm text-zinc-400 hover:text-white transition-colors">Wallet</a>
          <a href="#finance" className="text-sm text-zinc-400 hover:text-white transition-colors">Finance</a>
          <a href="#security" className="text-sm text-zinc-400 hover:text-white transition-colors">Security</a>
          <a href="#features" className="text-sm text-zinc-400 hover:text-white transition-colors">Features</a>
        </motion.div>
        <motion.button
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-sm text-zinc-400 hover:text-white transition-colors"
        >
          Presentation
        </motion.button>
      </nav>

      {/* Hero Text - Behind the 3D card (z-0) */}
      <div className="absolute inset-0 z-0 flex items-center justify-center pointer-events-none">
        <motion.h1
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 0.12, scale: 1 }}
          transition={{ duration: 1.2, ease: 'easeOut' }}
          className="text-[120px] sm:text-[160px] lg:text-[220px] font-light tracking-[-0.04em] text-white select-none"
          style={{ textShadow: '0 0 80px rgba(59,130,246,0.2)' }}
        >
          Wallet Tech
        </motion.h1>
      </div>

      {/* Bottom left content */}
      <div className="absolute bottom-12 left-0 z-30 section-padding">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="max-w-sm"
        >
          <p className="text-zinc-400 text-sm leading-relaxed mb-6">
            Smart finance solutions built to simplify digital payments and manage assets efficiently.
          </p>
          <button className="btn-primary flex items-center gap-2 group">
            <span>Start</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.div>
      </div>

      {/* Bottom right - Woman silhouette card */}
      <motion.div
        initial={{ opacity: 0, x: 30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 1.2, duration: 0.8 }}
        className="absolute bottom-12 right-8 lg:right-16 z-30"
      >
        <div className="relative w-40 h-52 rounded-2xl overflow-hidden liquid-glass">
          <img
            src="/woman-silhouette.jpg"
            alt="Professional"
            className="w-full h-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-blue-900/40 to-transparent" />
        </div>
      </motion.div>

      {/* Bottom gradient border */}
      <div className="absolute bottom-0 left-0 right-0 h-px z-30">
        <div className="h-full bg-gradient-to-r from-transparent via-blue-500/50 to-transparent" />
      </div>
    </section>
  )
}
