import { useRef, useEffect, Suspense } from 'react'
import { Canvas, useFrame, useLoader } from '@react-three/fiber'
// drei unused import removed
import { motion, useInView } from 'framer-motion'
import * as THREE from 'three'
import gsap from 'gsap'
import { ArrowRight } from 'lucide-react'

/* ─── Custom Shader Material for Mesh Distortion ─── */
const vertexShader = `
  varying vec2 vUv;
  uniform float uTime;
  uniform vec2 uMouse;
  uniform float uHover;

  float circle(vec2 uv, vec2 circlePosition, float radius) {
    float dist = distance(circlePosition, uv);
    return 1.0 - smoothstep(0.0, radius, dist);
  }

  float elevation(float radius, float intensity, vec2 uv) {
    float circleShape = circle(uv, (uMouse * 0.5) + 0.5, radius);
    return circleShape * intensity * uHover;
  }

  void main() {
    vUv = uv;
    vec3 newPosition = position;
    float shaderElevation = elevation(0.25, 0.8, vUv);
    newPosition.z += shaderElevation;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(newPosition, 1.0);
  }
`

const fragmentShader = `
  varying vec2 vUv;
  uniform sampler2D uTexture;

  void main() {
    vec4 finalTexture = texture2D(uTexture, vUv);
    gl_FragColor = finalTexture;
  }
`

/* ─── Distortion Image Mesh ─── */
function DistortionMesh() {
  const meshRef = useRef<THREE.Mesh>(null)
  const materialRef = useRef<THREE.ShaderMaterial>(null)
  const tex = useLoader(THREE.TextureLoader, '/wallet-coins.jpg')
  const hoverRef = useRef({ value: 0 })

  useEffect(() => {
    gsap.to(hoverRef.current, {
      value: 1,
      duration: 1.5,
      ease: 'power2.out',
    })
  }, [])

  const uniforms = useRef({
    uTexture: { value: tex },
    uTime: { value: 0 },
    uMouse: { value: new THREE.Vector2(0, 0) },
    uHover: { value: 0 },
  })

  useFrame(({ clock }) => {
    if (materialRef.current) {
      materialRef.current.uniforms.uTime.value = clock.getElapsedTime()
      materialRef.current.uniforms.uHover.value = THREE.MathUtils.lerp(
        materialRef.current.uniforms.uHover.value,
        hoverRef.current.value,
        0.05
      )
    }
  })

  const handlePointerMove = (e: THREE.Event) => {
    const native = (e as any).nativeEvent || e
    if (!native?.uv) return
    const uv = native.uv
    if (materialRef.current) {
      materialRef.current.uniforms.uMouse.value.set(uv.x * 2 - 1, uv.y * 2 - 1)
    }
  }

  return (
    <mesh
      ref={meshRef}
      onPointerMove={handlePointerMove}
      scale={[4, 2.8, 1]}
    >
      <planeGeometry args={[1, 1, 64, 64]} />
      <shaderMaterial
        ref={materialRef}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms.current}
      />
    </mesh>
  )
}

/* ─── Floating Coins (decorative) ─── */
function FloatingCoins() {
  const groupRef = useRef<THREE.Group>(null)

  useFrame(({ clock }) => {
    if (!groupRef.current) return
    const t = clock.getElapsedTime()
    groupRef.current.children.forEach((child, i) => {
      child.position.y = Math.sin(t * 0.8 + i * 1.2) * 0.15
      child.rotation.y = t * 0.3 + i
    })
  })

  return (
    <group ref={groupRef}>
      {[0, 1, 2].map((i) => (
        <mesh key={i} position={[1.5 + i * 0.6, 0.8 - i * 0.3, 0.5]}>
          <cylinderGeometry args={[0.15, 0.15, 0.04, 32]} />
          <meshStandardMaterial
            color={i === 0 ? '#FFD700' : i === 1 ? '#C0C0C0' : '#CD7F32'}
            metalness={1}
            roughness={0.2}
          />
        </mesh>
      ))}
    </group>
  )
}

/* ─── 3D Scene ─── */
function WalletScene() {
  return (
    <>
      <ambientLight intensity={0.6} />
      <pointLight position={[5, 5, 5]} intensity={1} color="#ffffff" />
      <pointLight position={[-5, -5, 3]} intensity={0.5} color="#3B82F6" />
      <DistortionMesh />
      <FloatingCoins />
    </>
  )
}

/* ─── Main Smart Wallet Section ─── */
export default function SmartWalletSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const isInView = useInView(sectionRef, { once: true, margin: '-100px' })

  return (
    <section
      id="wallet"
      ref={sectionRef}
      className="relative w-full min-h-screen bg-[#050505] overflow-hidden py-20 lg:py-32"
    >
      {/* Subtle background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-blue-600/5 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto section-padding">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left - 3D Canvas */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="relative aspect-[4/3] w-full"
          >
            {/* Label */}
            <div className="absolute top-4 left-4 z-10">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#3B82F6" strokeWidth="2">
                    <path d="M20 12V8H6a2 2 0 01-2-2c0-1.1.9-2 2-2h12v4" />
                    <path d="M4 6v12a2 2 0 002 2h14v-4" />
                    <path d="M18 12a2 2 0 100 4 2 2 0 000-4z" />
                  </svg>
                </div>
              </div>
              <h3 className="text-white font-medium text-lg">Smart wallet</h3>
              <p className="text-zinc-500 text-sm mt-1">Smart finance tools for daily transactions.</p>
            </div>

            <Suspense fallback={null}>
              <Canvas camera={{ position: [0, 0, 3], fov: 50 }}>
                <WalletScene />
              </Canvas>
            </Suspense>
          </motion.div>

          {/* Right - Text Content */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex flex-col justify-center"
          >
            <h2 className="text-3xl sm:text-4xl lg:text-[48px] font-light text-white leading-[1.15] tracking-[-0.03em] mb-8">
              Modern wallet solution<br />
              for seamless and<br />
              secure transactions
            </h2>

            <div className="flex items-start gap-4 mb-8">
              <div className="w-1 h-12 bg-gradient-to-b from-blue-500 to-transparent rounded-full" />
              <p className="text-zinc-400 text-sm leading-relaxed max-w-xs">
                Secure and efficient digital payment system.
              </p>
            </div>

            <button className="btn-primary w-fit flex items-center gap-2 group">
              <div className="w-2 h-2 rounded-full bg-white" />
              <span>Explore now</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
