import { useRef } from 'react'
import { motion, useInView, useScroll, useTransform } from 'framer-motion'
import { ArrowRight, TrendingUp } from 'lucide-react'

export default function SmartFinanceSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const isInView = useInView(sectionRef, { once: true, margin: '-100px' })
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start'],
  })

  // Parallax transforms at different speeds
  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '30%'])
  const contentY = useTransform(scrollYProgress, [0, 1], ['0%', '10%'])
  const foreX = useTransform(scrollYProgress, [0, 1], ['0%', '-15%'])

  return (
    <section
      id="finance"
      ref={sectionRef}
      className="relative w-full min-h-screen overflow-hidden"
    >
      {/* Blue gradient background layer */}
      <motion.div
        style={{ y: bgY }}
        className="absolute inset-0 bg-gradient-to-br from-[#0a1628] via-[#0c2040] to-[#051018]"
      >
        {/* Radial glow center */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_50%,_rgba(59,130,246,0.2)_0%,_transparent_60%)]" />
        {/* Cyan accent glow */}
        <div className="absolute top-1/3 right-1/4 w-[400px] h-[400px] rounded-full bg-cyan-500/10 blur-[100px]" />
      </motion.div>

      {/* Grid lines - Foreground layer */}
      <motion.div
        style={{ x: foreX }}
        className="absolute inset-0 z-10 pointer-events-none opacity-20"
      >
        <div className="absolute inset-0" style={{
          backgroundImage: `
            linear-gradient(rgba(59,130,246,0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(59,130,246,0.1) 1px, transparent 1px)
          `,
          backgroundSize: '80px 80px',
        }} />
        {/* Glowing crosshairs */}
        <div className="absolute top-1/4 left-1/3 w-[200px] h-[1px] bg-gradient-to-r from-transparent via-blue-400 to-transparent" />
        <div className="absolute top-1/4 left-1/3 w-[1px] h-[200px] bg-gradient-to-b from-transparent via-blue-400 to-transparent -translate-y-1/2" />
        <div className="absolute bottom-1/3 right-1/4 w-[150px] h-[1px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />
      </motion.div>

      {/* Content */}
      <motion.div
        style={{ y: contentY }}
        className="relative z-20 min-h-screen flex items-center"
      >
        <div className="max-w-7xl mx-auto w-full section-padding py-20">
          <div className="grid lg:grid-cols-12 gap-8 items-center">
            {/* Left - Woman silhouette */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 1 }}
              className="lg:col-span-4 relative"
            >
              <div className="relative aspect-[3/4] max-w-sm mx-auto lg:mx-0">
                <img
                  src="/woman-silhouette.jpg"
                  alt="Professional"
                  className="w-full h-full object-cover rounded-3xl"
                  style={{ filter: 'brightness(0.7) contrast(1.2)' }}
                />
                {/* Blue rim overlay */}
                <div className="absolute inset-0 rounded-3xl bg-gradient-to-r from-blue-500/20 to-transparent mix-blend-overlay" />
              </div>

              {/* Floating Performance Card */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.6, duration: 0.8 }}
                className="absolute -bottom-6 -right-4 lg:right-auto lg:-right-12"
              >
                <div className="liquid-glass rounded-2xl p-4 w-44">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-2 h-2 rounded-full bg-blue-400" />
                    <span className="text-zinc-300 text-xs font-medium">Performance</span>
                  </div>
                  {/* Mini chart */}
                  <svg width="120" height="40" viewBox="0 0 120 40" className="mb-2">
                    <path
                      d="M0 35 Q20 30, 30 25 T60 20 T90 10 T120 5"
                      fill="none"
                      stroke="#06B6D4"
                      strokeWidth="2"
                      strokeLinecap="round"
                    />
                    <path
                      d="M0 35 Q20 30, 30 25 T60 20 T90 10 T120 5 V40 H0 Z"
                      fill="url(#chartGradient)"
                      opacity="0.3"
                    />
                    <defs>
                      <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#06B6D4" />
                        <stop offset="100%" stopColor="#06B6D4" stopOpacity="0" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="flex items-baseline gap-1">
                    <span className="text-white text-2xl font-light">135K%</span>
                    <TrendingUp className="w-4 h-4 text-cyan-400" />
                  </div>
                </div>
              </motion.div>
            </motion.div>

            {/* Right - Main Typography */}
            <div className="lg:col-span-8 lg:pl-12">
              <motion.h2
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="text-4xl sm:text-5xl lg:text-7xl font-light text-white leading-[1.05] tracking-[-0.03em] mb-6"
              >
                <span className="text-gradient-blue">Smart Finance</span><br />
                for Modern<br />
                Users
              </motion.h2>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="text-zinc-400 text-base leading-relaxed max-w-md mb-8"
              >
                Manage your money with simple, secure, and intelligent financial solutions.
              </motion.p>

              <motion.button
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: 0.6 }}
                className="btn-primary flex items-center gap-2 group"
              >
                <span>View platform</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </motion.button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Bottom glow line */}
      <div className="absolute bottom-0 left-0 right-0 h-px z-20">
        <div className="h-full bg-gradient-to-r from-transparent via-blue-500/30 to-transparent" />
      </div>
    </section>
  )
}
