import { useRef, useState, useCallback } from 'react'
import { motion, useInView } from 'framer-motion'
import { ArrowRight, Mail, MapPin, Phone } from 'lucide-react'

const cards = [
  {
    id: 'ticket',
    title: 'Support Ticket',
    subtitle: 'Priority Support',
    image: '/card-ticket.jpg',
    gradient: 'from-cyan-500/20 to-blue-500/20',
  },
  {
    id: 'bank',
    title: 'Premium Card',
    subtitle: 'Lunétra Platinum',
    image: '/card-bank.jpg',
    gradient: 'from-blue-500/20 to-purple-500/20',
  },
  {
    id: 'profile',
    title: 'Your Profile',
    subtitle: 'Verified Member',
    image: '/card-profile.jpg',
    gradient: 'from-purple-500/20 to-cyan-500/20',
  },
]

export default function FooterSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const isInView = useInView(sectionRef, { once: true, margin: '-50px' })
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 })
  const wrapperRef = useRef<HTMLDivElement>(null)

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!wrapperRef.current) return
    const rect = wrapperRef.current.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 2
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * 2
    setMousePos({ x, y })
  }, [])

  const handleMouseLeave = useCallback(() => {
    setMousePos({ x: 0, y: 0 })
  }, [])

  return (
    <footer
      ref={sectionRef}
      className="relative w-full bg-[#050505] overflow-hidden pt-20 lg:pt-32 pb-8"
    >
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-blue-600/5 rounded-full blur-[150px]" />

      <div className="relative z-10 max-w-7xl mx-auto section-padding">
        {/* Top CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-light text-white tracking-[-0.02em] mb-6">
            Ready to experience<br />
            <span className="text-gradient-blue">the future of finance?</span>
          </h2>
          <button className="btn-primary inline-flex items-center gap-2 group">
            <span>Get Started</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.div>

        {/* Interactive Card Stack */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex justify-center mb-20"
        >
          <div
            ref={wrapperRef}
            className="relative w-72 h-96 perspective-1000 cursor-pointer"
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
          >
            {cards.map((card, i) => {
              const offsetX = mousePos.x * (15 + i * 8)
              const offsetY = mousePos.y * (10 + i * 5)
              const rotX = -mousePos.y * (8 + i * 3)
              const rotY = mousePos.x * (10 + i * 4)
              const zOffset = i * 30 + Math.abs(mousePos.x) * 10

              return (
                <motion.div
                  key={card.id}
                  className="absolute inset-0 preserve-3d"
                  animate={{
                    x: offsetX + i * -8,
                    y: offsetY + i * 5,
                    rotateX: rotX,
                    rotateY: rotY,
                    z: zOffset,
                  }}
                  transition={{ type: 'spring', stiffness: 150, damping: 20 }}
                  style={{
                    zIndex: cards.length - i,
                    transformOrigin: 'center center',
                  }}
                >
                  <div
                    className={`w-full h-full rounded-3xl overflow-hidden shadow-2xl border border-white/10 bg-gradient-to-br ${card.gradient}`}
                    style={{
                      boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
                    }}
                  >
                    <img
                      src={card.image}
                      alt={card.title}
                      className="w-full h-full object-cover opacity-90"
                    />
                    <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
                      <span className="text-zinc-400 text-xs">{card.subtitle}</span>
                      <h4 className="text-white font-medium">{card.title}</h4>
                    </div>
                  </div>
                </motion.div>
              )
            })}
          </div>
        </motion.div>

        {/* Footer Links */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 py-12 border-t border-white/5">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
                <span className="text-white font-bold text-sm">L</span>
              </div>
              <span className="text-white font-medium text-lg">Lunétra</span>
            </div>
            <p className="text-zinc-500 text-sm leading-relaxed">
              The next generation of digital finance. Secure, fast, and intelligent.
            </p>
          </div>

          {/* Product */}
          <div>
            <h4 className="text-white font-medium text-sm mb-4">Product</h4>
            <ul className="space-y-3">
              {['Wallet', 'Cards', 'Exchange', 'Rewards'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-zinc-500 text-sm hover:text-blue-400 transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-white font-medium text-sm mb-4">Company</h4>
            <ul className="space-y-3">
              {['About', 'Careers', 'Blog', 'Press'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-zinc-500 text-sm hover:text-blue-400 transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-medium text-sm mb-4">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-zinc-500 text-sm">
                <Mail className="w-4 h-4 text-blue-400" />
                hello@lunetra.com
              </li>
              <li className="flex items-center gap-2 text-zinc-500 text-sm">
                <Phone className="w-4 h-4 text-blue-400" />
                +1 (555) 000-0000
              </li>
              <li className="flex items-center gap-2 text-zinc-500 text-sm">
                <MapPin className="w-4 h-4 text-blue-400" />
                San Francisco, CA
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between py-6 border-t border-white/5 gap-4">
          <p className="text-zinc-600 text-xs">
            © 2025 Lunétra. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            {['Privacy', 'Terms', 'Cookies'].map((item) => (
              <a
                key={item}
                href="#"
                className="text-zinc-600 text-xs hover:text-zinc-400 transition-colors"
              >
                {item}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
