import { useRef, useMemo } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { motion, useInView } from 'framer-motion'
import * as THREE from 'three'

/* ─── Starfield Background ─── */
function Starfield() {
  const pointsRef = useRef<THREE.Points>(null)
  const count = 2000

  const [positions, sizes] = useMemo(() => {
    const positions = new Float32Array(count * 3)
    const sizes = new Float32Array(count)
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 50
      positions[i * 3 + 1] = (Math.random() - 0.5) * 50
      positions[i * 3 + 2] = (Math.random() - 0.5) * 50
      sizes[i] = Math.random() * 2 + 0.5
    }
    return [positions, sizes]
  }, [])

  useFrame(({ clock }) => {
    if (!pointsRef.current) return
    pointsRef.current.rotation.y = clock.getElapsedTime() * 0.01
    pointsRef.current.rotation.x = clock.getElapsedTime() * 0.005
  })

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-size" args={[sizes, 1]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.03}
        color="#3B82F6"
        transparent
        opacity={0.6}
        sizeAttenuation
      />
    </points>
  )
}

/* ─── Floating Pills ─── */
function FloatingPills({ isInView }: { isInView: boolean }) {
  const pills = [
    { text: 'Secure system', x: '15%', y: '25%', delay: 0 },
    { text: 'Key features', x: '75%', y: '70%', delay: 0.3 },
  ]

  return (
    <>
      {pills.map((pill, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ delay: 0.8 + pill.delay, duration: 0.6 }}
          className="absolute z-20"
          style={{ left: pill.x, top: pill.y }}
        >
          <motion.div
            animate={{
              y: [0, -8, 0],
            }}
            transition={{
              duration: 3 + i,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="flex items-center gap-3 px-5 py-3 rounded-full liquid-glass-strong"
          >
            <div className="w-2.5 h-2.5 rounded-full bg-gradient-to-r from-blue-400 to-cyan-400" />
            <span className="text-white text-sm font-medium whitespace-nowrap">{pill.text}</span>
            {/* Decorative line */}
            <div className="absolute -right-16 top-1/2 w-16 h-px bg-gradient-to-r from-blue-500/40 to-transparent" />
          </motion.div>
        </motion.div>
      ))}
    </>
  )
}

/* ─── Main Security Section ─── */
export default function SecuritySection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const isInView = useInView(sectionRef, { once: true, margin: '-100px' })

  const words = ['Secure', 'digital', 'payments', 'made', 'simple', 'for', 'modern.']

  return (
    <section
      id="security"
      ref={sectionRef}
      className="relative w-full min-h-screen bg-[#050505] overflow-hidden py-20 lg:py-32"
    >
      {/* Starfield Canvas Background */}
      <div className="absolute inset-0 z-0">
        <Canvas camera={{ position: [0, 0, 10], fov: 60 }}>
          <Starfield />
        </Canvas>
      </div>

      {/* Subtle vignette */}
      <div className="absolute inset-0 z-[1] bg-[radial-gradient(ellipse_at_center,_transparent_0%,_rgba(5,5,5,0.6)_100%)]" />

      {/* Floating pills */}
      <FloatingPills isInView={isInView} />

      {/* Main content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center section-padding">
        {/* Large typography */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center max-w-4xl mx-auto mb-12"
        >
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-light leading-[1.15] tracking-[-0.02em]">
            {words.map((word, i) => (
              <motion.span
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.3 + i * 0.08, duration: 0.5 }}
                className={`inline-block mr-[0.3em] ${
                  word === 'Secure' || word === 'modern.'
                    ? 'text-gradient-blue font-normal'
                    : 'text-white'
                }`}
              >
                {word}
              </motion.span>
            ))}
          </h2>
        </motion.div>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 1.2, duration: 0.6 }}
          className="text-zinc-500 text-center text-sm max-w-md"
        >
          Built for fast transactions and reliable financial management.
        </motion.p>

        {/* Decorative elements */}
        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          animate={isInView ? { opacity: 0.5, scale: 1 } : {}}
          transition={{ delay: 1.5, duration: 0.8 }}
          className="absolute top-1/4 right-[15%] w-2 h-2 rounded-full bg-blue-400"
        />
        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          animate={isInView ? { opacity: 0.3, scale: 1 } : {}}
          transition={{ delay: 1.7, duration: 0.8 }}
          className="absolute bottom-1/3 left-[20%] w-1.5 h-1.5 rounded-full bg-cyan-400"
        />
      </div>
    </section>
  )
}
