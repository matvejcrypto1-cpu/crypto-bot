import { useLenis } from '@/hooks/useLenis'
import HeroSection from '@/sections/HeroSection'
import SmartWalletSection from '@/sections/SmartWalletSection'
import SmartFinanceSection from '@/sections/SmartFinanceSection'
import SecuritySection from '@/sections/SecuritySection'
import FeaturesSection from '@/sections/FeaturesSection'
import FooterSection from '@/sections/FooterSection'

export default function App() {
  useLenis()

  return (
    <main className="relative bg-[#050505] overflow-x-hidden">
      <HeroSection />
      <SmartWalletSection />
      <SmartFinanceSection />
      <SecuritySection />
      <FeaturesSection />
      <FooterSection />
    </main>
  )
}
