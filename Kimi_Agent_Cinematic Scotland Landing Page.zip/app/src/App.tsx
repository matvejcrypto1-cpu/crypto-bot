import { useLenis } from './hooks/useLenis';
import Navigation from './sections/Navigation';
import Hero from './sections/Hero';
import Intro from './sections/Intro';
import Expeditions from './sections/Expeditions';
import BentoGrid from './sections/BentoGrid';
import JourneysReel from './sections/JourneysReel';
import TourTimeline from './sections/TourTimeline';
import GlassGallery from './sections/GlassGallery';
import BookingCTA from './sections/BookingCTA';
import Footer from './sections/Footer';

export default function App() {
  useLenis();

  return (
    <div className="relative bg-scotland-dark min-h-screen">
      <Navigation />
      <Hero />
      <Intro />
      <Expeditions />
      <BentoGrid />
      <JourneysReel />
      <TourTimeline />
      <GlassGallery />
      <BookingCTA />
      <Footer />
    </div>
  );
}
