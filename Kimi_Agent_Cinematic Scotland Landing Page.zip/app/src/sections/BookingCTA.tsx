import { useRef } from 'react';
import { motion, useScroll, useTransform, useInView } from 'framer-motion';

export default function BookingCTA() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-15%' });

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start'],
  });

  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '30%']);
  const contentY = useTransform(scrollYProgress, [0, 1], ['0%', '-10%']);

  return (
    <section
      id="booking"
      ref={sectionRef}
      className="relative w-full min-h-screen overflow-hidden flex items-center justify-center"
    >
      {/* Parallax background image */}
      <motion.div className="absolute inset-0 -top-[20%] -bottom-[20%]" style={{ y: bgY }}>
        <img
          src="/images/castle-misty.jpg"
          alt="Misty Scottish Castle"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-scotland-dark/50" />
      </motion.div>

      {/* Content */}
      <motion.div
        className="relative z-10 text-center max-w-3xl mx-auto px-6"
        style={{ y: contentY }}
      >
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, ease: [0.25, 0.1, 0.25, 1] }}
          className="font-sans text-[11px] tracking-[0.3em] uppercase text-scotland-gold mb-8"
        >
          Your Adventure Awaits
        </motion.p>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{
            duration: 0.9,
            delay: 0.1,
            ease: [0.25, 0.1, 0.25, 1],
          }}
          className="font-serif text-5xl md:text-7xl text-scotland-light mb-8"
          style={{ fontWeight: 300, lineHeight: 1.1 }}
        >
          Begin Your
          <br />
          Journey
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{
            duration: 0.8,
            delay: 0.2,
            ease: [0.25, 0.1, 0.25, 1],
          }}
          className="font-sans text-[15px] leading-[1.8] text-scotland-light/70 mb-12 max-w-lg mx-auto"
        >
          Let us craft a bespoke Scottish experience tailored to your spirit of
          adventure. From the Edinburgh cobblestones to the Skye wilderness.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{
            duration: 0.8,
            delay: 0.3,
            ease: [0.25, 0.1, 0.25, 1],
          }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <button className="px-10 py-4 bg-scotland-gold text-scotland-dark font-sans text-[12px] tracking-[0.2em] uppercase hover:bg-scotland-light transition-colors duration-500">
            Book a Consultation
          </button>
          <button className="px-10 py-4 border border-scotland-light/30 text-scotland-light font-sans text-[12px] tracking-[0.2em] uppercase hover:border-scotland-gold hover:text-scotland-gold transition-all duration-500">
            View All Tours
          </button>
        </motion.div>
      </motion.div>
    </section>
  );
}
