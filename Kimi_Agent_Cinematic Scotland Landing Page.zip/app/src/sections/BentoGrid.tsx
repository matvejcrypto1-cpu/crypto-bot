import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const bentoItems = [
  {
    id: 1,
    title: 'The Highland Coo',
    subtitle: 'Meet the locals',
    image: '/images/highland-coo.jpg',
    size: 'large',
  },
  {
    id: 2,
    title: 'Cuillin Ridge',
    subtitle: 'Munro bagging',
    image: '/images/highlands-aerial.jpg',
    size: 'wide',
  },
  {
    id: 3,
    title: 'Skye Coastline',
    subtitle: 'Atlantic drama',
    image: '/images/skye-coast.jpg',
    size: 'tall',
  },
  {
    id: 4,
    title: 'Loch Ness',
    subtitle: 'Mystery & myth',
    image: '/images/loch-ness.jpg',
    size: 'small',
  },
];

export default function BentoGrid() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-10%' });

  return (
    <section
      ref={sectionRef}
      className="relative w-full bg-scotland-dark"
      style={{ padding: '100px 24px 140px' }}
    >
      <div className="max-w-7xl mx-auto">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, ease: [0.25, 0.1, 0.25, 1] }}
          className="font-sans text-[12px] tracking-[0.25em] uppercase text-scotland-light/50 mb-16"
        >
          Highlights
        </motion.p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 auto-rows-[280px]">
          {bentoItems.map((item, i) => {
            const gridClass =
              item.size === 'large'
                ? 'md:col-span-2 md:row-span-2'
                : item.size === 'wide'
                ? 'md:col-span-2'
                : item.size === 'tall'
                ? 'md:row-span-2'
                : 'md:col-span-1';

            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 40 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{
                  duration: 0.8,
                  delay: 0.12 * i,
                  ease: [0.25, 0.1, 0.25, 1],
                }}
                className={`group relative overflow-hidden cursor-pointer ${gridClass}`}
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-scotland-dark/80 via-scotland-dark/20 to-transparent" />
                <div className="absolute bottom-0 left-0 p-6">
                  <p className="font-sans text-[10px] tracking-[0.2em] uppercase text-scotland-gold/80 mb-1">
                    {item.subtitle}
                  </p>
                  <h3 className="font-serif text-2xl text-scotland-light">
                    {item.title}
                  </h3>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
