import { useRef, useMemo } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

const vertexShader = `
precision mediump float;
varying vec2 vUv;
uniform float uTime;

void main() {
  vUv = uv;
  vec3 pos = position;
  float frequency = 0.2;
  float amplitude = 0.5;
  pos.y += sin(pos.x * frequency + uTime) * amplitude;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
}
`;

const fragmentShader = `
precision mediump float;
varying vec2 vUv;
uniform float uTime;
uniform float uBigCircleSpeed;
uniform float uSmallCircleSpeed;
uniform float uColorIntensity;

float random(vec2 st) {
  return fract(sin(dot(st.xy, vec2(12.9898,78.233))) * 43758.5453123);
}

float noise(vec2 st) {
  vec2 i = floor(st);
  vec2 f = fract(st);
  float a = random(i);
  float b = random(i + vec2(1.0, 0.0));
  float c = random(i + vec2(0.0, 1.0));
  float d = random(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(a, b, u.x) + (c - a)* u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

void main() {
  float aspect = 0.8;
  vec2 uv = vUv * aspect;
  float distCenter = distance(uv, vec2(0.5 * aspect, 0.5));
  float angle1 = uTime * uBigCircleSpeed;
  float angle2 = -uTime * uSmallCircleSpeed;
  vec2 smallCirclePos = vec2(0.5 * aspect + cos(angle2) * 0.15, 0.5 + sin(angle2) * 0.15);
  float distSmallCircle = distance(uv, smallCirclePos);
  float closeToSmallCircle = smoothstep(0.15, 0.0, distSmallCircle);
  float orbitRadius = 0.2 + closeToSmallCircle * 0.1;
  vec2 orbitCenter = vec2(0.5 * aspect + cos(angle1) * orbitRadius, 0.5 + sin(angle1) * orbitRadius);
  float distOrbit = distance(uv, orbitCenter);
  float distFlat = distance(uv, vec2(0.5 * aspect, 0.0));
  float finalDist = mix(distCenter, distOrbit, 0.6);
  finalDist = mix(finalDist, distFlat, 0.3);
  float n = noise(vec2(vUv.x * 6.0, vUv.y * 6.0 - uTime * 0.2)) * 0.4 + noise(vec2(vUv.x * 12.0 + uTime * 0.1, vUv.y * 12.0)) * 0.3;
  float pattern = finalDist + (n * 0.15);
  float highlight = smoothstep(0.4, 0.6, pattern);
  highlight = smoothstep(0.48, 0.5, highlight) - smoothstep(0.5, 0.52, highlight);
  vec3 slateGrey = vec3(0.41, 0.45, 0.49);
  vec3 darkBlue = vec3(0.02, 0.08, 0.16);
  vec3 emeraldGreen = vec3(0.07, 0.24, 0.18);
  vec3 greenTint = vec3(0.2, 0.3, 0.22);
  float colorMix = noise(vec2(vUv.x * 3.0, vUv.y * 3.0 + uTime * 0.1));
  vec3 deepColor = mix(darkBlue, emeraldGreen, colorMix);
  vec3 finalColor = mix(deepColor, slateGrey, highlight);
  finalColor = mix(finalColor, greenTint, n * 0.2);
  float goldAccent = smoothstep(0.45, 0.55, n);
  goldAccent *= 0.3;
  vec3 goldColor = vec3(0.79, 0.66, 0.43);
  finalColor += goldColor * goldAccent;
  float vignette = smoothstep(0.9, 0.3, distance(vUv, vec2(0.5, 0.5)));
  finalColor *= vignette;
  gl_FragColor = vec4(finalColor * uColorIntensity, 1.0);
}
`;

function LiquidPlane() {
  const meshRef = useRef<THREE.Mesh>(null);
  const materialRef = useRef<THREE.ShaderMaterial>(null);
  const { viewport } = useThree();

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0.0 },
      uBigCircleSpeed: { value: 0.8 },
      uSmallCircleSpeed: { value: 1.2 },
      uColorIntensity: { value: 1.2 },
    }),
    []
  );

  useFrame((state) => {
    if (materialRef.current) {
      materialRef.current.uniforms.uTime.value = state.clock.getElapsedTime();
    }
    if (meshRef.current) {
      meshRef.current.scale.set(viewport.width, viewport.height, 1);
    }
    state.camera.position.x = Math.sin(state.clock.elapsedTime * 0.1) * 5;
    state.camera.lookAt(0, 0, 0);
  });

  return (
    <mesh ref={meshRef}>
      <planeGeometry args={[1, 1, 32, 32]} />
      <shaderMaterial
        ref={materialRef}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

export default function HeroShader() {
  return (
    <div className="absolute inset-0 z-0">
      <Canvas
        orthographic
        camera={{ position: [0, 0, 10], zoom: 1, near: 0.1, far: 100 }}
        gl={{ antialias: true, alpha: false }}
        style={{ width: '100%', height: '100%' }}
      >
        <LiquidPlane />
      </Canvas>
    </div>
  );
}
