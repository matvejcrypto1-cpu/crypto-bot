import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

export default function Footer() {
  const footerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(footerRef, { once: true, margin: '-10%' });

  return (
    <footer
      ref={footerRef}
      className="relative w-full bg-scotland-dark border-t border-scotland-light/5"
      style={{ padding: '120px 24px 60px' }}
    >
      <div className="max-w-7xl mx-auto">
        {/* Large heading */}
        <motion.h2
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, ease: [0.25, 0.1, 0.25, 1] }}
          className="font-serif text-4xl md:text-6xl text-scotland-light mb-20"
          style={{ fontWeight: 300, lineHeight: 1.1 }}
        >
          Begin Your
          <br />
          Journey
        </motion.h2>

        {/* Links grid */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{
            duration: 0.8,
            delay: 0.2,
            ease: [0.25, 0.1, 0.25, 1],
          }}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-20"
        >
          <div>
            <p className="font-sans text-[10px] tracking-[0.25em] uppercase text-scotland-light/40 mb-4">
              Explore
            </p>
            <ul className="space-y-3">
              <li>
                <a
                  href="#expeditions"
                  className="font-sans text-[13px] text-scotland-light/70 hover:text-scotland-gold transition-colors duration-300"
                >
                  All Tours
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="font-sans text-[13px] text-scotland-light/70 hover:text-scotland-gold transition-colors duration-300"
                >
                  Bespoke Journeys
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="font-sans text-[13px] text-scotland-light/70 hover:text-scotland-gold transition-colors duration-300"
                >
                  Group Expeditions
                </a>
              </li>
            </ul>
          </div>

          <div>
            <p className="font-sans text-[10px] tracking-[0.25em] uppercase text-scotland-light/40 mb-4">
              Company
            </p>
            <ul className="space-y-3">
              <li>
                <a
                  href="#"
                  className="font-sans text-[13px] text-scotland-light/70 hover:text-scotland-gold transition-colors duration-300"
                >
                  Our Philosophy
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="font-sans text-[13px] text-scotland-light/70 hover:text-scotland-gold transition-colors duration-300"
                >
                  Journal
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="font-sans text-[13px] text-scotland-light/70 hover:text-scotland-gold transition-colors duration-300"
                >
                  Careers
                </a>
              </li>
            </ul>
          </div>

          <div>
            <p className="font-sans text-[10px] tracking-[0.25em] uppercase text-scotland-light/40 mb-4">
              Support
            </p>
            <ul className="space-y-3">
              <li>
                <a
                  href="#"
                  className="font-sans text-[13px] text-scotland-light/70 hover:text-scotland-gold transition-colors duration-300"
                >
                  Contact
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="font-sans text-[13px] text-scotland-light/70 hover:text-scotland-gold transition-colors duration-300"
                >
                  FAQ
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="font-sans text-[13px] text-scotland-light/70 hover:text-scotland-gold transition-colors duration-300"
                >
                  Terms
                </a>
              </li>
            </ul>
          </div>

          <div>
            <p className="font-sans text-[10px] tracking-[0.25em] uppercase text-scotland-light/40 mb-4">
              Connect
            </p>
            <ul className="space-y-3">
              <li>
                <a
                  href="#"
                  className="font-sans text-[13px] text-scotland-light/70 hover:text-scotland-gold transition-colors duration-300"
                >
                  Instagram
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="font-sans text-[13px] text-scotland-light/70 hover:text-scotland-gold transition-colors duration-300"
                >
                  Twitter
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="font-sans text-[13px] text-scotland-light/70 hover:text-scotland-gold transition-colors duration-300"
                >
                  Newsletter
                </a>
              </li>
            </ul>
          </div>
        </motion.div>

        {/* Gold accent line */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={isInView ? { scaleX: 1 } : {}}
          transition={{ duration: 1.2, delay: 0.4, ease: [0.25, 0.1, 0.25, 1] }}
          className="w-full h-[1px] bg-scotland-gold/30 mb-8 origin-left"
        />

        {/* Copyright */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col md:flex-row items-center justify-between gap-4"
        >
          <p className="font-sans text-[11px] tracking-[0.15em] text-scotland-light/30">
            &copy; 2026 Caledonian Journeys. All rights reserved.
          </p>
          <p className="font-sans text-[11px] tracking-[0.15em] text-scotland-light/30">
            Edinburgh, Scotland
          </p>
        </motion.div>
      </div>
    </footer>
  );
}
