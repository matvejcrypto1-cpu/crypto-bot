import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Navigation() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav
      className="fixed top-0 left-0 w-full z-50 mix-blend-difference"
      style={{ padding: '28px 40px' }}
    >
      <div className="flex items-center justify-between max-w-[1800px] mx-auto">
        {/* Wordmark */}
        <a
          href="#"
          className="font-sans text-[13px] tracking-[0.25em] uppercase text-scotland-light hover:text-scotland-gold transition-colors duration-300"
        >
          Caledonian Journeys
        </a>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-10">
          <a
            href="#expeditions"
            className="font-sans text-[12px] tracking-[0.2em] uppercase text-scotland-light/80 hover:text-scotland-light transition-colors duration-300"
          >
            Tours
          </a>
          <a
            href="#timeline"
            className="font-sans text-[12px] tracking-[0.2em] uppercase text-scotland-light/80 hover:text-scotland-light transition-colors duration-300"
          >
            Philosophy
          </a>
          <a
            href="#"
            className="font-sans text-[12px] tracking-[0.2em] uppercase text-scotland-light/80 hover:text-scotland-light transition-colors duration-300"
          >
            Journal
          </a>
          <a
            href="#booking"
            className="ml-4 px-5 py-2 border border-scotland-gold/60 rounded-full font-sans text-[11px] tracking-[0.2em] uppercase text-scotland-gold hover:bg-scotland-gold hover:text-scotland-dark transition-all duration-500"
          >
            Book
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden flex flex-col gap-1.5"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          <span className={`block w-6 h-[1px] bg-scotland-light transition-all duration-300 ${menuOpen ? 'rotate-45 translate-y-[3.5px]' : ''}`} />
          <span className={`block w-6 h-[1px] bg-scotland-light transition-all duration-300 ${menuOpen ? '-rotate-45 -translate-y-[3.5px]' : ''}`} />
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4, ease: [0.25, 0.1, 0.25, 1] }}
            className="md:hidden absolute top-full left-0 w-full bg-scotland-dark/95 backdrop-blur-xl border-t border-scotland-light/10"
          >
            <div className="flex flex-col items-center gap-8 py-12">
              <a
                href="#expeditions"
                onClick={() => setMenuOpen(false)}
                className="font-sans text-[14px] tracking-[0.2em] uppercase text-scotland-light/80 hover:text-scotland-gold transition-colors"
              >
                Tours
              </a>
              <a
                href="#timeline"
                onClick={() => setMenuOpen(false)}
                className="font-sans text-[14px] tracking-[0.2em] uppercase text-scotland-light/80 hover:text-scotland-gold transition-colors"
              >
                Philosophy
              </a>
              <a
                href="#"
                onClick={() => setMenuOpen(false)}
                className="font-sans text-[14px] tracking-[0.2em] uppercase text-scotland-light/80 hover:text-scotland-gold transition-colors"
              >
                Journal
              </a>
              <a
                href="#booking"
                onClick={() => setMenuOpen(false)}
                className="px-8 py-3 border border-scotland-gold rounded-full font-sans text-[12px] tracking-[0.2em] uppercase text-scotland-gold hover:bg-scotland-gold hover:text-scotland-dark transition-all duration-500"
              >
                Book Your Journey
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
