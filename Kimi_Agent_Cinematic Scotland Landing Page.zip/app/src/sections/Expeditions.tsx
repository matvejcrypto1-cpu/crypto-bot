import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const expeditions = [
  {
    id: 1,
    title: 'ISLE OF SKYE INTENSIVE',
    image: '/images/old-man-storr.jpg',
    tag: '7 Days',
  },
  {
    id: 2,
    title: 'GLENCOE TREK',
    image: '/images/glencoe.jpg',
    tag: '5 Days',
  },
  {
    id: 3,
    title: 'EILEAN DONAN CASTLE',
    image: '/images/eilean-donan.jpg',
    tag: '3 Days',
  },
  {
    id: 4,
    title: 'LOCH NESS VOYAGE',
    image: '/images/loch-ness.jpg',
    tag: '4 Days',
  },
];

export default function Expeditions() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-10%' });

  return (
    <section
      id="expeditions"
      ref={sectionRef}
      className="relative w-full bg-scotland-dark"
      style={{ padding: '140px 24px' }}
    >
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, ease: [0.25, 0.1, 0.25, 1] }}
          className="font-sans text-[12px] tracking-[0.25em] uppercase text-scotland-light/50 mb-16"
        >
          Expeditions
        </motion.p>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {expeditions.map((exp, i) => (
            <motion.div
              key={exp.id}
              initial={{ opacity: 0, y: 60 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.9,
                delay: 0.15 * i,
                ease: [0.25, 0.1, 0.25, 1],
              }}
              className="group relative aspect-[4/5] overflow-hidden cursor-pointer"
            >
              {/* Image */}
              <div className="absolute inset-0 overflow-hidden">
                <img
                  src={exp.image}
                  alt={exp.title}
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105 grayscale group-hover:grayscale-0"
                />
              </div>

              {/* Gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-scotland-dark/90 via-scotland-dark/20 to-transparent" />

              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-8 flex items-end justify-between">
                <div>
                  <p className="font-sans text-[10px] tracking-[0.2em] uppercase text-scotland-gold mb-2">
                    {exp.tag}
                  </p>
                  <h3 className="font-sans text-[14px] tracking-[0.15em] uppercase text-scotland-light">
                    {exp.title}
                  </h3>
                </div>
                {/* Gold accent line */}
                <div className="w-12 h-[2px] bg-scotland-gold group-hover:w-20 transition-all duration-500" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
