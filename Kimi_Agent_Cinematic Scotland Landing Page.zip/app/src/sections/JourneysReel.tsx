import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

export default function JourneysReel() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-10%' });

  return (
    <section
      ref={sectionRef}
      className="relative w-full bg-scotland-dark"
      style={{ padding: '80px 24px' }}
    >
      <div className="max-w-[1600px] mx-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 1, ease: [0.25, 0.1, 0.25, 1] }}
          className="relative w-full overflow-hidden"
          style={{ aspectRatio: '21/9' }}
        >
          <video
            autoPlay
            muted
            loop
            playsInline
            className="absolute inset-0 w-full h-full object-cover"
          >
            <source src="/videos/highland-atmosphere.mp4" type="video/mp4" />
          </video>

          {/* Subtle overlay */}
          <div className="absolute inset-0 bg-scotland-dark/20" />

          {/* Frosted glass pill */}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
            <div className="px-6 py-2.5 rounded-full bg-scotland-dark/30 backdrop-blur-md border border-scotland-light/10">
              <p className="font-sans text-[10px] tracking-[0.3em] uppercase text-scotland-light/80">
                IMMERSIVE 360° JOURNEYS
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
