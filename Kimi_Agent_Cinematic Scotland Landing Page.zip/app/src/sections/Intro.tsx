import { useRef, useEffect, useState } from 'react';
import { motion, useInView } from 'framer-motion';

export default function Intro() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-20%' });
  const [active, setActive] = useState(false);

  useEffect(() => {
    if (isInView) {
      const timer = setTimeout(() => setActive(true), 200);
      return () => clearTimeout(timer);
    }
  }, [isInView]);

  const words = [
    'We', 'curate', 'journeys', 'into', 'the',
    'untamed', 'edges', 'of', 'the', 'British',
    'Isles.', 'Experiences', 'designed', 'to', 'strip',
    'away', 'the', 'modern', 'and', 'reconnect',
    'with', 'the', 'elemental.',
  ];

  const maxBlur = 8;

  return (
    <section
      ref={sectionRef}
      className="relative w-full min-h-screen flex items-center justify-center bg-scotland-dark"
      style={{ padding: '120px 24px' }}
    >
      <div className="max-w-4xl mx-auto">
        <p
          className="font-serif text-scotland-light text-center leading-[1.4]"
          style={{ fontSize: 'clamp(24px, 4vw, 48px)', fontWeight: 300 }}
        >
          {words.map((word, i) => {
            return (
              <motion.span
                key={i}
                className="inline-block mr-[0.3em]"
                initial={{ opacity: 0.2, filter: `blur(${maxBlur}px)` }}
                animate={
                  active
                    ? { opacity: 1, filter: 'blur(0px)' }
                    : { opacity: 0.2, filter: `blur(${maxBlur}px)` }
                }
                transition={{
                  duration: 0.6,
                  delay: i * 0.06,
                  ease: [0.25, 0.1, 0.25, 1],
                }}
                style={{
                  whiteSpace: 'nowrap',
                }}
              >
                {word}
              </motion.span>
            );
          })}
        </p>

        {/* Decorative line */}
        <motion.div
          className="mx-auto mt-16 h-[1px] bg-scotland-gold/40"
          initial={{ width: 0 }}
          animate={active ? { width: 80 } : { width: 0 }}
          transition={{ duration: 1, delay: 1.5, ease: [0.25, 0.1, 0.25, 1] }}
        />
      </div>
    </section>
  );
}
