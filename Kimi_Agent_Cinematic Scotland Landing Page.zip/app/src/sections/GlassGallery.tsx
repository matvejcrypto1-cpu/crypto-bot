import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const galleryItems = [
  {
    id: 1,
    image: '/images/eilean-donan.jpg',
    title: 'Eilean Donan',
    category: 'Castle',
  },
  {
    id: 2,
    image: '/images/glencoe.jpg',
    title: 'Glencoe Valley',
    category: 'Highlands',
  },
  {
    id: 3,
    image: '/images/old-man-storr.jpg',
    title: 'Old Man of Storr',
    category: 'Isle of Skye',
  },
  {
    id: 4,
    image: '/images/highland-coo.jpg',
    title: 'Highland Coo',
    category: 'Wildlife',
  },
  {
    id: 5,
    image: '/images/loch-ness.jpg',
    title: 'Loch Ness',
    category: 'Mystery',
  },
  {
    id: 6,
    image: '/images/highlands-aerial.jpg',
    title: 'Cuillin Ridge',
    category: 'Mountains',
  },
];

export default function GlassGallery() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-10%' });

  return (
    <section
      ref={sectionRef}
      className="relative w-full bg-scotland-dark overflow-hidden"
      style={{ padding: '140px 24px' }}
    >
      <div className="max-w-7xl mx-auto">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, ease: [0.25, 0.1, 0.25, 1] }}
          className="font-sans text-[12px] tracking-[0.25em] uppercase text-scotland-light/50 mb-16"
        >
          Gallery
        </motion.p>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {galleryItems.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.7,
                delay: 0.1 * i,
                ease: [0.25, 0.1, 0.25, 1],
              }}
              className={`group relative overflow-hidden cursor-pointer ${
                i === 0 || i === 3 ? 'aspect-[3/4]' : 'aspect-square'
              }`}
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
              />

              {/* Glass morphism overlay */}
              <div className="absolute inset-x-0 bottom-0 p-5 bg-scotland-dark/40 backdrop-blur-md border-t border-scotland-light/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out">
                <p className="font-sans text-[9px] tracking-[0.25em] uppercase text-scotland-gold mb-1">
                  {item.category}
                </p>
                <h4 className="font-serif text-lg text-scotland-light">
                  {item.title}
                </h4>
              </div>

              {/* Always-visible subtle gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-scotland-dark/50 via-transparent to-transparent group-hover:opacity-0 transition-opacity duration-500" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
