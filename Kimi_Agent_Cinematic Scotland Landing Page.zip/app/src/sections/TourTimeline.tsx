import { useRef } from 'react';
import { motion, useScroll, useTransform, useInView } from 'framer-motion';

const tours = [
  {
    id: 1,
    title: 'EDINBURGH',
    subtitle: 'The Royal Beginning',
    description:
      'Start your journey in Scotland\'s historic capital. Wander the cobbled streets of the Old Town, explore the towering Edinburgh Castle, and immerse yourself in the city\'s rich tapestry of history, culture, and whisky.',
    image: '/images/edinburgh-castle.jpg',
    days: '2 Days',
    price: 'From £890',
  },
  {
    id: 2,
    title: 'HIGHLANDS',
    subtitle: 'Into the Wild',
    description:
      'Venture north into the dramatic Scottish Highlands. Traverse the haunting beauty of Glencoe, cruise the mysterious waters of Loch Ness, and stand in awe beneath Ben Nevis, Britain\'s highest peak.',
    image: '/images/highlands-aerial.jpg',
    days: '4 Days',
    price: 'From £1,450',
  },
  {
    id: 3,
    title: 'ISLE OF SKYE',
    subtitle: 'The Final Frontier',
    description:
      'Complete your odyssey on the Isle of Skye. Discover the otherworldly landscapes of the Quiraing, the fairy pools, and the dramatic Cuillin Ridge — a place where myth and reality blur into one.',
    image: '/images/skye-coast.jpg',
    days: '5 Days',
    price: 'From £1,890',
  },
];

function TourItem({
  tour,
  index,
}: {
  tour: (typeof tours)[0];
  index: number;
}) {
  const itemRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(itemRef, { once: true, margin: '-15%' });

  const { scrollYProgress } = useScroll({
    target: itemRef,
    offset: ['start end', 'center center'],
  });

  const imageScale = useTransform(scrollYProgress, [0, 1], [1.2, 1]);
  const titleX = useTransform(scrollYProgress, [0, 1], [100, 0]);
  const titleOpacity = useTransform(scrollYProgress, [0, 0.6], [0, 1]);
  const textY = useTransform(scrollYProgress, [0, 1], [60, 0]);
  const textOpacity = useTransform(scrollYProgress, [0, 0.8], [0, 1]);

  const isEven = index % 2 === 0;

  return (
    <div
      ref={itemRef}
      className="relative min-h-screen grid place-items-center"
      style={{ padding: '80px 24px' }}
    >
      {/* Background image */}
      <motion.div
        className="absolute inset-0 overflow-hidden"
        style={{ scale: imageScale }}
      >
        <img
          src={tour.image}
          alt={tour.title}
          className="w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-scotland-dark via-scotland-dark/70 to-scotland-dark" />
      </motion.div>

      {/* Large watermark title */}
      <motion.h2
        className="absolute font-serif text-scotland-light/10 uppercase pointer-events-none select-none z-[1]"
        style={{
          fontSize: 'clamp(60px, 12vw, 180px)',
          letterSpacing: '-0.04em',
          fontWeight: 300,
          lineHeight: 1,
          x: titleX,
          opacity: titleOpacity,
          ...(isEven ? { left: '5%', top: '50%', transform: 'translateY(-50%)' } : { right: '5%', top: '50%', transform: 'translateY(-50%)' }),
        }}
      >
        {tour.title}
      </motion.h2>

      {/* Content card */}
      <motion.div
        className="relative z-10 max-w-md w-full"
        style={{
          y: textY,
          opacity: textOpacity,
          ...(isEven ? { marginLeft: 'auto', marginRight: '10%' } : { marginRight: 'auto', marginLeft: '10%' }),
        }}
      >
        <div className="bg-scotland-dark/80 backdrop-blur-xl border border-scotland-light/10 p-8 md:p-10">
          <div className="flex items-center gap-4 mb-6">
            <span className="font-sans text-[10px] tracking-[0.25em] uppercase text-scotland-gold">
              {tour.days}
            </span>
            <div className="flex-1 h-[1px] bg-scotland-light/10" />
            <span className="font-sans text-[10px] tracking-[0.15em] text-scotland-light/50">
              {tour.price}
            </span>
          </div>

          <h3 className="font-serif text-3xl md:text-4xl text-scotland-light mb-2">
            {tour.title}
          </h3>
          <p className="font-sans text-[11px] tracking-[0.2em] uppercase text-scotland-gold/80 mb-6">
            {tour.subtitle}
          </p>
          <p className="font-sans text-[14px] leading-[1.7] text-scotland-light/70 mb-8">
            {tour.description}
          </p>

          <button className="group flex items-center gap-3 font-sans text-[11px] tracking-[0.2em] uppercase text-scotland-gold hover:text-scotland-light transition-colors duration-300">
            <span>Explore Tour</span>
            <span className="w-6 h-[1px] bg-scotland-gold group-hover:w-10 transition-all duration-300" />
          </button>
        </div>
      </motion.div>

      {/* SVG connecting line */}
      {index < tours.length - 1 && (
        <motion.div
          className="absolute bottom-0 left-1/2 -translate-x-1/2 z-20"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.8 }}
        >
          <svg width="2" height="80" viewBox="0 0 2 80" fill="none">
            <motion.line
              x1="1"
              y1="0"
              x2="1"
              y2="80"
              stroke="#c9a96e"
              strokeWidth="1"
              initial={{ pathLength: 0 }}
              animate={isInView ? { pathLength: 1 } : {}}
              transition={{ duration: 1.2, delay: 0.5, ease: 'easeInOut' }}
            />
          </svg>
        </motion.div>
      )}
    </div>
  );
}

export default function TourTimeline() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-5%' });

  return (
    <section
      id="timeline"
      ref={sectionRef}
      className="relative w-full bg-scotland-dark overflow-hidden"
    >
      {/* Section header */}
      <div style={{ padding: '140px 24px 60px' }}>
        <div className="max-w-7xl mx-auto">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, ease: [0.25, 0.1, 0.25, 1] }}
            className="font-sans text-[12px] tracking-[0.25em] uppercase text-scotland-light/50 mb-4"
          >
            The Journey
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{
              duration: 0.9,
              delay: 0.1,
              ease: [0.25, 0.1, 0.25, 1],
            }}
            className="font-serif text-4xl md:text-5xl text-scotland-light"
            style={{ fontWeight: 300 }}
          >
            Three Realms
          </motion.h2>
        </div>
      </div>

      {/* Timeline items */}
      {tours.map((tour, i) => (
        <TourItem key={tour.id} tour={tour} index={i} />
      ))}
    </section>
  );
}
