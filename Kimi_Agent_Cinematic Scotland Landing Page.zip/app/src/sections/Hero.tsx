import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import HeroShader from './HeroShader';
import { ChevronDown } from 'lucide-react';

export default function Hero() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end start'],
  });

  const titleY = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const subtitleY = useTransform(scrollYProgress, [0, 1], [0, 100]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 1.1]);

  return (
    <section
      ref={containerRef}
      className="relative w-full h-screen overflow-hidden bg-scotland-dark"
    >
      {/* R3F Shader Background */}
      <motion.div style={{ scale }} className="absolute inset-0 z-0">
        <HeroShader />
      </motion.div>

      {/* Overlay gradient for depth */}
      <div className="absolute inset-0 z-[1] bg-gradient-to-b from-scotland-dark/30 via-transparent to-scotland-dark/60" />

      {/* Top label */}
      <motion.div
        style={{ y: subtitleY, opacity }}
        className="absolute top-[120px] left-1/2 -translate-x-1/2 z-10"
      >
        <p className="font-sans text-[11px] tracking-[0.35em] uppercase text-scotland-light/60 text-center">
          The Wild North / Since 2026
        </p>
      </motion.div>

      {/* Massive SCOTLAND title */}
      <motion.div
        style={{ y: titleY, opacity }}
        className="absolute inset-0 z-[2] flex items-center justify-center pointer-events-none"
      >
        <h1
          className="font-serif text-scotland-light uppercase select-none"
          style={{
            fontSize: 'clamp(80px, 18vw, 280px)',
            letterSpacing: '-0.08em',
            lineHeight: 0.85,
            fontWeight: 300,
            textShadow: '0 0 120px rgba(13, 17, 23, 0.5)',
          }}
        >
          Scotland
        </h1>
      </motion.div>

      {/* Bottom chevron */}
      <motion.div
        style={{ opacity }}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 z-10"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        >
          <ChevronDown className="w-5 h-5 text-scotland-light/40" strokeWidth={1} />
        </motion.div>
      </motion.div>
    </section>
  );
}
